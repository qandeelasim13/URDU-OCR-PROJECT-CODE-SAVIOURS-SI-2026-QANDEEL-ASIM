
## Week 2: Preprocessing + OCR Gap Analysis

### What was done
- Loaded the 265 labeled Urdu images collected in Week 1 across
  8 sources (see `data/labels.csv`).
- Applied a preprocessing pipeline (grayscale -> denoise -> adaptive threshold ->
  deskew -> resize) to every image.
- Saved 265 preprocessed images to `data/processed/`
  (0 images failed to process) and linked raw/processed pairs in
  `data/processed_labels.csv`.
- Tested Tesseract OCR (lang='urd') on 8 sampled images spanning all
  sources, both raw and preprocessed.

### Result summary
- Average Character Error Rate on RAW images: 84.8%
- Average Character Error Rate on PREPROCESSED images: 86.8%
- Preprocessing did NOT reduce the average CER overall -- CER actually rose by 2.0% (from 84.8% to 86.8%). It helped on 'augmented_blur' but made results worse on 'synthetic'. This shows that cleaner-looking images do not automatically mean better OCR: Tesseract's core inability to model Nastaliq letterforms is the real bottleneck, not image quality alone.

Tesseract's Urdu output was frequently incomplete, garbled, or entirely incorrect
on Nastaliq-style text, both before and after preprocessing. Preprocessing improved
visual contrast and reduced noise, but did not reliably fix Tesseract's core
inability to model Nastaliq's diagonal, overlapping, context-dependent letterforms
-- confirming that the bottleneck is the OCR engine itself, not image quality.

### Why Tesseract fails on Urdu
1. Nastaliq is highly cursive with position-dependent letterforms.
2. Diagonal baseline and overlapping ligatures break standard character segmentation.
3. Tesseract's Urdu model is trained on limited, low-diversity data.
4. Dot/diacritic-based letter distinctions are lost at low resolution.
5. Word-boundary assumptions (built for Latin scripts) don't hold for Nastaliq spacing.

### Why this project matters
This gap is the core justification for building a custom Urdu OCR model
(e.g. CNN/CRNN + CTC or Transformer-based) trained specifically on Nastaliq script
data, rather than relying on general-purpose OCR engines or preprocessing alone.
