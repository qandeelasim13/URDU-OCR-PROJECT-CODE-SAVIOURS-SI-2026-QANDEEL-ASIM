
## Why We Need a Better Model

### What was done
- Loaded the 265 labeled Urdu images collected in Week 1 across
  8 sources (see `data/labels.csv`).
- Applied a preprocessing pipeline (grayscale -> denoise -> adaptive threshold ->
  deskew -> resize) to every image.
- Saved 265 preprocessed images to `data/processed/`
  (0 images failed to process) and linked raw/processed pairs in
  `data/processed_labels.csv`.
- Tested Tesseract OCR (lang='urd') on 8 sampled images spanning all
  sources, both raw and preprocessed.

### Result summary
- Average Character Error Rate on RAW images: 84.8%
- Average Character Error Rate on PREPROCESSED images: 86.8%
- Preprocessing did NOT reduce the average CER overall -- CER actually rose by 2.0% (from 84.8% to 86.8%). It helped on 'augmented_blur' but made results worse on 'synthetic'. This shows that cleaner-looking images do not automatically mean better OCR: Tesseract's core inability to model Nastaliq letterforms is the real bottleneck, not image quality alone.

### Per-image breakdown (5 worst-performing samples)
**Image 1 (synthetic, CER 118.4%)**
- Actual Urdu text: پاکستان کا قیام چودہ اگست انیس سو سینتالیس کو ہوا
- Tesseract output: ‎۲٢ ۳۲۳۲1۷۲'۳۲۲۲(-2۲‏ 7000ا 0ا3ہ آتحلہ۔'تت:۵نت-ہ]۲- 0 080 فآ0آ000
- What went wrong: Output is almost entirely wrong: the characters printed are unrelated to the ground truth -- essentially gibberish rather than a genuine reading attempt.

**Image 2 (books_synthetic, CER 100.0%)**
- Actual Urdu text: وقت کی قدر کرنے والے ہی زندگی میں کامیاب ہوتے ہیں۔ گزرا ہوا وقت کبھی واپس نہیں آتا۔
- Tesseract output: (empty -- no text detected)
- What went wrong: Tesseract produced no output at all -- completely blank/empty result.

**Image 3 (signboards_synthetic, CER 100.0%)**
- Actual Urdu text: سگریٹ نوشی منع ہے
- Tesseract output: 0000
- What went wrong: Output is almost entirely wrong: the characters printed are unrelated to the ground truth -- essentially gibberish rather than a genuine reading attempt.

**Image 4 (augmented_rotation, CER 96.9%)**
- Actual Urdu text: غالب اردو شاعری کے عظیم شاعر تھے
- Tesseract output: 0000000000000000 0
- What went wrong: Output is almost entirely wrong: the characters printed are unrelated to the ground truth -- essentially gibberish rather than a genuine reading attempt.

**Image 5 (augmented_brightness, CER 95.1%)**
- Actual Urdu text: آرٹیفیشل انٹیلیجنس مستقبل کی ٹیکنالوجی ہے
- Tesseract output: ]۲۲۲٢۱۱۱۱۲۷َٰ۷ََٰ/ت۱‎ 00
- What went wrong: Output is almost entirely wrong: the characters printed are unrelated to the ground truth -- essentially gibberish rather than a genuine reading attempt.


### Summary
Tesseract fails on Urdu because it was trained mainly on Naskh-style printed text, not the cursive, diagonally-flowing Nastaliq script most Urdu text actually uses. Nastaliq's overlapping ligatures and position-dependent letterforms break Tesseract's character segmentation, its Urdu language model is trained on limited, low-diversity data that does not generalize to real-world fonts and noise, and small dot/diacritic differences between otherwise identical letters are lost at normal image resolutions -- together explaining the consistently high error rates measured above.

### Why Tesseract fails on Urdu (general reasons)
1. Nastaliq is highly cursive with position-dependent letterforms.
2. Diagonal baseline and overlapping ligatures break standard character segmentation.
3. Tesseract's Urdu model is trained on limited, low-diversity data.
4. Dot/diacritic-based letter distinctions are lost at low resolution.
5. Word-boundary assumptions (built for Latin scripts) don't hold for Nastaliq spacing.

### Why this project matters
This gap is the core justification for building a custom Urdu OCR model
(e.g. CNN/CRNN + CTC or Transformer-based) trained specifically on Nastaliq script
data, rather than relying on general-purpose OCR engines or preprocessing alone.
